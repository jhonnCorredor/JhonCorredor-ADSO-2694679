
package Interface;


public interface Interface {
    void Suma();
    void Resta();
    void Multiplicacion();
    void Division();
}
