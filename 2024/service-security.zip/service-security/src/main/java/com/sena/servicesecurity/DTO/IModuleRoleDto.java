package com.sena.servicesecurity.DTO;

public interface IModuleRoleDto extends IGenericDto{


	String getModule();
	String getRole();
}
